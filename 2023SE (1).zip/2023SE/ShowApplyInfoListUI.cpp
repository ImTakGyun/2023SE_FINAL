#include "ShowApplyInfoListUI.hpp"
#include "ApplyInfo.hpp"
#include "App.hpp"

ShowApplyInfoListUI::ShowApplyInfoListUI(){}

ShowApplyInfoListUI::~ShowApplyInfoListUI(){}

// 회원의 지원정보들을 출력한다.
void    ShowApplyInfoListUI::startInterface()
{   
    fprintf(_fout, "4.3. 지원 정보 조회\n");
}

void ShowApplyInfoListUI::showResult(vector<ApplyInfo*> ApplyList)
{   
    ApplyInfoDetail applyInfoDetail;

    // 최신의 지원정보부터 출력하기위해 역순으로 접근한다.
    for(int i=(ApplyList.size() - 1); i >= 0; i--){
        applyInfoDetail = ApplyList[i]->getApplyInfoDetail();
        fprintf(_fout, "%s %s %s %d %s \n", applyInfoDetail.companyName, applyInfoDetail.businessNumber, applyInfoDetail.task, applyInfoDetail.numOfPersonnel, applyInfoDetail.deadline );
    }
}