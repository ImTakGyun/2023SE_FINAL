#include "ApplyRecruitInfo.hpp"
#include "Server.hpp"
#include "RecruitInfo.hpp"

void  ApplyRecruitInfo::addNewApplyInfo(GeneralMember* member, RecruitInfoDetail recruitInfoDetail)
{
    member->createNewApplyInfo(recruitInfoDetail);
    _applyRecruitInfoUI.showResult(recruitInfoDetail);
}

ApplyRecruitInfo::ApplyRecruitInfo(){}
ApplyRecruitInfo::~ApplyRecruitInfo(){}

void ApplyRecruitInfo::run()
{
    Server* server = Server::getInstance();

    //현재 접속해있는 사용자의 정보를 받아온다.
    GeneralMember* member = NULL;
    member = dynamic_cast<GeneralMember*>(server->getCurMember());

    vector<Member*> MemberList = server->getMemberList();
    
    _applyRecruitInfoUI.startInterface();

    for(int i=0; i<MemberList.size(); i++){

        //Member의 type이 '2'(회사회원)이면서 type 값이 2인 Member를 회사회원으로 cast하여 사업자번호를 비교한다.
        // if(MemberList[i]->getType() == 2 &&
        //      dynamic_cast<CompanyMember*>(MemberList[i])->getbusinessNumber() == _applyRecruitInfoUI.applyRecruit()){
            
        //     CompanyMember* companyMember = dynamic_cast<CompanyMember*>(MemberList[i]);

        //     //회사회원이 등록한 채용공고들 중(vector<RecruitInfo*>)에서 마지막으로 등록한(현재 사용중인 채용공고)를 읽어온다.
        //     //vector<RecruitInfo*>의 마지막 내용을 읽어오기 위한 end()... 하지만 iterator 형식에 의해 -1을 고민해주어야 한다. 
        //     //=> 이거 그냥 vector의 back() 함수 사용하면 될 것 같습니다!
        //     RecruitInfo* info = companyMember->listRecruitInfo().back();

        //     // RecruitInfo를 가져왔다면 지원자 수를 늘려주고 지원정보를 생성한다.
        //     info -> increaseApplyNum();
        //     addNewApplyInfo(member, info -> getRecruitInfoDetail());
        //     break;
        // }
    
    }
}