#pragma once
#include "BasicUI.hpp"


class ShowApplyInfoListUI : public BasicUI
{
private:
public:
    ShowApplyInfoListUI();
    ~ShowApplyInfoListUI();
    void  startInterface();
    void showResult(vector<ApplyInfo*> ApplyList);
};