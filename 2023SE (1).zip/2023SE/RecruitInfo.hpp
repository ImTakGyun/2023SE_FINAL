#pragma once
#include "App.hpp"

class RecruitInfo
{
private:
    string          _companyName;
    string          _task;
    string          _deadline;
    unsigned int    _numOfPersonnel;
    unsigned int    _numOfApplicants;

public:
    RecruitInfoDetail   getRecruitInfoDetail();
    //기존: setApplyNum(); => 변경: increaseApplyNum();
    void                increaseApplyNum();
    //지원 취소시에 지원자수를 줄이는 로직도 일단은 넣어보겠습니다.
    void                decreaseApplyNum();       
    RecruitInfo(string companyName, string task, string deadline, unsigned int numOfPersonnel);
    ~RecruitInfo();
};
