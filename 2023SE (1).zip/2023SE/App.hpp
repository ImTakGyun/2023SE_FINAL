#pragma once

#include <string>
#include <iostream>
#include <fstream>
#include <vector>


using namespace std;


#define MAX_STRING 32
#define MAX_APPLY_NUM 100
#define COMPANY_MEMBER_TYPE 1
#define GENERAL_MEMBER_TYPE 2
#define INPUT_FILE_NAME "input.txt"
#define OUTPUT_FILE_NAME "output.txt"

#define LOGOUT 1

typedef struct _RecruitInfoDetail
{
    string companyName;
    // 사업자 번호 필드 추가
    string businessNumber;
    string task;
    string deadline;
    unsigned int numOfPersonnel;
} RecruitInfoDetail;

// _RecruitInfoDetail와 겹치지만 병합시 충돌 우려로 인하여, 직관적인 이름의 struct를 위하여 생성
typedef struct _ApplyInfoDetail
{
    string companyName;
    string businessNumber;
    string task;
    string deadline;
    unsigned int numOfPersonnel;
} ApplyInfoDetail;

typedef struct _RegisterForm
{
    int type;
    string name;
    string number;
    string id;
    string pw;
} RegisterForm;

typedef struct _LoginForm
{
    string id;
    string pw;
} LoginForm;
