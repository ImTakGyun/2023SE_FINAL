#pragma once
#include "App.hpp"

class Member
{
private:
    string          _id;
    string          _pw;
    //int             _type;
    int			   	_state;

public:
    bool    checkValid();
	int		changeAccessState();
    string  getId();
    string  getPw();
    //int     getType();
	virtual void	checkInfo() = 0;

    //Member(string id, string pw, int type);
    Member(string id, string pw);
    
    ~Member();
};

