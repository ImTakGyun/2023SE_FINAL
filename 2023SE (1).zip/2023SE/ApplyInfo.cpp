#include "ApplyInfo.hpp"

ApplyInfo::ApplyInfo(string companyName, string businessNumber, string task, string deadline, unsigned int numOfPersonnel) : _companyName(companyName), _businessNumber(_businessNumber), _task(task), _deadline(deadline), _numOfPersonnel(numOfPersonnel) 
{
    cout << "지원 정보 생성 : " << companyName << " " << businessNumber << " " << task << " " << numOfPersonnel << " " << deadline << endl ;
}

ApplyInfoDetail ApplyInfo::getApplyInfoDetail()
{
    ApplyInfoDetail applyInfoDetail = {_companyName, _businessNumber, _task, _deadline, _numOfPersonnel};
    return applyInfoDetail;
}

// 불필요한 setApplyNum() 삭제