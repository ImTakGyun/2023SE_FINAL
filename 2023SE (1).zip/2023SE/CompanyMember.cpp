#include "CompanyMember.hpp"

CompanyMember::CompanyMember(string companyName, string businessNumber,string id, string pw) : Member(id, pw) , _companyName(companyName), _businessNumber(businessNumber) 
{
    cout << 2 << " 회사회원 " << companyName << " " << businessNumber << " " <<  id << " " << pw << endl;
}
// CompanyMember::CompanyMember(int type, string companyName, string businessNumber,string id, string pw) : Member(id, pw, type) , _companyName(companyName), _businessNumber(businessNumber) 
// {
//     cout << type << " 회사회원 " << companyName << " " << businessNumber << " " <<  id << " " << pw << endl;
// }

CompanyMember::~CompanyMember(){}

unsigned int    CompanyMember::totalApplicantsNum()
{
    return (0);
}
void            CompanyMember::addNewRecruitInfo()
{

}
vector<RecruitInfo*>    CompanyMember::listRecruitInfo()
{
    return _ownedRecuitInfos;
}

string  CompanyMember::getbusinessNumber()
{
    return _businessNumber;
}

void	CompanyMember::checkInfo()
{

}

