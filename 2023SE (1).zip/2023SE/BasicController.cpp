#include "BasicController.hpp"

BasicController::BasicController(){}
BasicController::~BasicController(){}
