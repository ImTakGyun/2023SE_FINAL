#include "ShowApplyInfoList.hpp"
#include "Server.hpp"

ShowApplyInfoList::ShowApplyInfoList(){}


void ShowApplyInfoList::run()
{
    Server* server = Server::getInstance();
    GeneralMember* member = NULL;
    member = dynamic_cast<GeneralMember*>(server->getCurMember());

    _showApplyInfoListUI.startInterface();
    _showApplyInfoListUI.showResult(member->listApplyInfo());
}

ShowApplyInfoList::~ShowApplyInfoList(){}