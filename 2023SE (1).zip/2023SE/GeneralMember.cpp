#pragma once
#include "BasicUI.hpp"
#include "GeneralMember.hpp"

GeneralMember::GeneralMember(string name, string residentNumber,string id, string pw) : Member(id, pw), _name(name), _residentNumber(residentNumber)
{
    cout << 1 << " 일반 회원 " << name << " " << residentNumber << " " <<  id << " " << pw << endl;
}
// GeneralMember::GeneralMember(int type, string name, string residentNumber,string id, string pw) : Member(id, pw, type), _name(name), _residentNumber(residentNumber)
// {
//     cout << type << " 일반 회원 " << name << " " << residentNumber << " " <<  id << " " << pw << endl;
// }

GeneralMember::~GeneralMember(){}

unsigned int    GeneralMember::totalApplyNum()
{
    return 0;
}

// 일반회원이 지금까지 지원한 지원정보들을 역순으로 비교하며 입력된 사업자번호로의 채용공고 중 가장 최근의 지원정보를 취소한다. (같은 기간동안 회사는 하나의 채용공고만 가능함)
// 이전에 같은 사업자번호의 채용공고에 지원한 지원 정보는 만료된 채용공고이므로 최근의 지원정보를 찾았다면 break로 빠져나온다.
ApplyInfoDetail            GeneralMember::cancelApplyInfo(string businessNumber)
{   
    ApplyInfoDetail applyInfoDetail;

    for(int i=(_ownedApplyInfos.size() - 1); i >= 0; i--){
        if(_ownedApplyInfos[i]->getApplyInfoDetail().businessNumber == businessNumber){

            applyInfoDetail = _ownedApplyInfos[i]->getApplyInfoDetail();

            //이렇게 소멸시키면 vector가 자동으로 줄어드나요...? 컴파일을 못해봐서 답답하네요...
            _ownedApplyInfos[i]->~ApplyInfo();
            break;
        }
    }
    return applyInfoDetail;
}

// 일반회원의 지원정보들을 반환해준다.
vector<ApplyInfo*>      GeneralMember::listApplyInfo()
{
    return _ownedApplyInfos;
}

// 채용공고에 지원하기를 통해 지원정보가 생성된다. 
//   -> 채용공고의 정보를 받아 지원정보를 생성
void            GeneralMember::createNewApplyInfo(RecruitInfoDetail recruitInfoDetail)
{
    ApplyInfo* applyInfo = NULL;
    applyInfo = new ApplyInfo(recruitInfoDetail.companyName, recruitInfoDetail.businessNumber, recruitInfoDetail.task, recruitInfoDetail.deadline, recruitInfoDetail.numOfPersonnel);
    _ownedApplyInfos.push_back(applyInfo);
}

void	GeneralMember::checkInfo()
{
    
}