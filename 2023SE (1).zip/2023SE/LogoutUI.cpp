#include "LogoutUI.hpp"

LogoutUI::LogoutUI(){}

LogoutUI::~LogoutUI(){}

void    LogoutUI::startInterface()
{
    fprintf(_fout, "2.2. 로그아웃\n");
}
