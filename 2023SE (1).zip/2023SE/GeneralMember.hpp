#pragma once
#include "Member.hpp"
#include "ApplyInfo.hpp"

class GeneralMember : public Member
{
private:
    string             _name;
    string             _residentNumber;
    vector<ApplyInfo*> _ownedApplyInfos;
    
public:
    unsigned int    totalApplyNum();
    ApplyInfoDetail     cancelApplyInfo(string businessNumber);
    vector<ApplyInfo*>  listApplyInfo();
    void            createNewApplyInfo(RecruitInfoDetail recruitInfoDetail);
    virtual void	checkInfo();
    //GeneralMember(int type, string name, string residentNumber,string id, string pw);
    GeneralMember(string name, string residentNumber,string id, string pw);
    ~GeneralMember();
};